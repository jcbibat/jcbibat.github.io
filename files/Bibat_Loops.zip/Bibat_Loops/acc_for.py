acc = 5
for i in range (acc):
    print(acc)
    acc = acc - 1
    
