acc = 5
x = 10
while x > 0:
    print(acc)
    acc = acc - 1
    x = x - 1
