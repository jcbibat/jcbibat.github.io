start = 1
stop = 11
iterate = 1
for i in range (start, stop, iterate):
    print(i)
