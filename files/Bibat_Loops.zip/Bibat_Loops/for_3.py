from time import sleep
print("Enter a number and I will count down!")
start = int(input())
stop = -1
iterate = -1
for i in range (start, stop, iterate):
    print(i)
    sleep(1)
print("Timer done!")

