
x = 1

while x <= 10:
    print(x)
    x = x + 1
