from time import sleep
print("Enter a number and I will count down!")
x = int(input())
while x > 0:
    print(x)
    x = x - 1
    sleep(1)
print("Timer done!")
    
