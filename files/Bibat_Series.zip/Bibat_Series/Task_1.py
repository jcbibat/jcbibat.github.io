sum  =  0
def f(n):
            x =n**2 + 3*n + 1
            return x
for i in range (2, 6):
            print(f(i))
            if i < 5:
                        print("+")
            else:
                        print("=")
            sum = sum + f(i)
print(sum)

