from math import factorial, pi
x = float(input("Please give me something: "))
def taylor(x):
            series = 0
            for n in range (86):
                        a = ((-1)**n)*(x**(2*n))/(factorial(2*n))
                        series = series + a
            return series
print(taylor(x))
