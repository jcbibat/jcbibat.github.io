from math import factorial, pi
x = int(input("Input an angle in degrees: "))
x = x * (pi/180)
def cosine(x):
            series = 0
            for n in range (86):
                        a = ((-1)**n)*(x**(2*n))/(factorial(2*n))
                        series = series + a
            return series
print(cosine(x))

