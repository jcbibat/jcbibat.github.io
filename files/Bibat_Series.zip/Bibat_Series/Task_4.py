from math import factorial, pi
def cosine(x):
            series = 0
            for n in range (86):
                        a = ((-1)**n)*(x**(2*n))/(factorial(2*n))
                        series = series + a
            return series
def taskFour():
            print("Is your angle in radians or degrees? Choose \'1\' for Radians and \'2\' for Degrees. \n 1. Radians \n 2. Degrees")
            y = int(input("Integer Input: "))
            if y == 1:
                        print("Give me a radian value.")
                        rad = float(input("Input: "))
                        print("The cosine of this angle is:" + str(cosine(rad)))
            if y == 2:
                        print("Give me a degree value.")
                        rad = float(input("Input: "))
                        rad = rad * (pi/180)
                        print("The cosine of this angle is:" + str(cosine(rad)))
taskFour()
