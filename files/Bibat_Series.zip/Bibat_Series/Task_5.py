def fib(n):
            a = 0
            b = 1
            acc = 0
            for i in range (0, n):
                        c = a
                        a = b
                        b = c + b
                        acc = acc + a
                        print(a)
                        if i < n-1 :
                                    print("+")
                        if i == n-1 :
                                    print("=")
            print(acc)
            return acc
print("Give me something")
n = int(input())
fib(n)


