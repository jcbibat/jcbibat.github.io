def multiPrev(n):
            a = 1
            acc = 0
            for i in range (0, n):
                        print(a)
                        acc = acc + a
                        a = a * 3
                        if i < n - 1:
                                    print("+")
                        if i == n - 1:
                                    print("=")
            print(acc)
            return acc
print("Give me something")
n = int(input())
multiPrev(n)
