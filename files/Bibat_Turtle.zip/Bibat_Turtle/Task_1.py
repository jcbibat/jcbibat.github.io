import turtle
t = turtle.Turtle()
turtle.colormode(255)

def tri(anyturtle, n):
    for i in range (3):
        anyturtle.forward(n)
        anyturtle.right(120)

def squa(anyturtle, n):
    for i in range (4):
        anyturtle.forward(n)
        anyturtle.right(90)

def pent(anyturtle, n):
    for i in range (5):
        anyturtle.forward(n)
        anyturtle.right(72)

def hex(anyturtle, n):
    for i in range (6):
        anyturtle.forward(n)
        anyturtle.right(60)
        
def nona(anyturtle, n):
    for i in range (9):
        anyturtle.forward(n)
        anyturtle.right(40)

def deca(anyturtle, n):
    for i in range (10):
        anyturtle.forward(n)
        anyturtle.right(36)

def AnyRegPoly(anyturtle, sideNumber, n):
    for i in range (sideNumber):
        anyturtle.fd(n)
        anyturtle.rt(360/sideNumber)

sideNumber = int(input("Sides of Shape: "))
n = int(input("Length of Side: "))
anyturtle = input("Name your Turtle: ")
anyturtle = turtle.Turtle()


AnyRegPoly(anyturtle,sideNumber,n)
anyturtle.color(255,255,255)
AnyRegPoly(anyturtle,sideNumber,n)
anyturtle.color(0,0,0)
tri(anyturtle,10)
squa(anyturtle,20)
pent(anyturtle,30)
hex(anyturtle,40)
nona(anyturtle,50)
deca(anyturtle, 60)


    
