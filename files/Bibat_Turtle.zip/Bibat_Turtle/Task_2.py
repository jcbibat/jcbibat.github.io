import turtle
from random import randint
sideNumber = int(input("Sides of Shape: "))
n = int(input("Length of Side: "))
t = input("Name your Turtle: ")
t = turtle.Turtle()
turtle.colormode(255)
turtle.bgcolor(24,85,65)
t.speed (5)

def AnyRegPoly(t, sideNumber, n):
    for i in range (sideNumber, 0, -1):
        t.fd(n)
        t.rt(360/sideNumber)
        r = randint(0,255)
        g = randint(0,255)
        b = randint(0,255)
        t.color(r, g, b)
        t.speed(5 - 1)
        
AnyRegPoly(t, sideNumber, n)
    
