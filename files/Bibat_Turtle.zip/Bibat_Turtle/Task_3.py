import turtle
sideNumber = int(input("Number of Sides: "))
t = input("Turtle Name: ")
t = turtle.Turtle()
window = turtle.Screen()
window.colormode(255)
t.speed(0)


def corn (t, sideNumber, n):
    for i in range (sideNumber):
        t.fd(n)
        t.rt(360/sideNumber)
        
def center(t, sideNumber, n):
    t.penup()
    t.goto(-n/2, n/2)
    t.pd()
    for i in range (sideNumber):
        t.fd(n)
        t.rt(360/sideNumber)

for i in range (0,30,2):
    corn(t, sideNumber, 2*i)

t.color(255, 255, 255)

for i in range (0,30,2):
    corn(t,sideNumber,2*i)
    
t.color(0, 0, 0)

for i in range (2,600,20):
    center(t,4,i)







































