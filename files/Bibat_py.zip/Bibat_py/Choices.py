from Functions import *
from time import sleep
import sys

suspend = 3
tries = 3

def intCheck(s):
  try: 
    float(s)
    return True
  except ValueError:
    return False

def delay_print(s):
    for c in s:
        sys.stdout.write( '%s' % c )
        sys.stdout.flush()
        sleep(0.03375)

              
def choiceOneA (tries, suspend):
    delay_print(" Are you ready now, " + user + "? \n 1. Yes \n 2. No \n")
    choiceOne = input("Input:")
    if suspend < 2:
        print("You are suspended indefinitely for not being able to follow simple instructions.")
        exit()
    if tries < 2:
        print("You must not be enrolled in the right class. Goodbye.")
        exit()
    if intCheck(choiceOne) == True and float(choiceOne) == 1:
        firstQuestion(suspend)
    if intCheck(choiceOne) == True and float(choiceOne) == 2:
       delay_print("Okay.")
       sleep(3.0)
       tries = tries - 1
       choiceOneA (tries, suspend)
    elif intCheck(choiceOne) == False or float(choiceOne) >= 2 or float(choiceOne) <= 0:
        print("Please comply and enter a proper input.")
        suspend = suspend - 1
        choiceOneA(tries, suspend)

def firstQuestion(suspend):
    a = input("Enter any integer:")
    if suspend < 2:
        print("You are suspended indefinitely for not being able to follow simple instructions.")
        exit()
    if intCheck(a) == True:
        delay_print("I, the omniscent and omnipotent Mr. Thoe, shall tell you the answer if one were to add six to that integer.")
        delay_print(" It is.... ")
        print(addSix(a))
        secondQuestion(suspend)
    elif intCheck(choiceOne) == False:
        print("Please comply and enter a proper input.")
        suspend = suspend - 1
        firstQuestion(suspend)
        
def secondQuestion(suspend):
    n = input("Enter ANOTHER integer:")
    if suspend < 2:
        print("You are suspended indefinitely for not being able to follow simple instructions.")
        exit()
    if intCheck(n) == True:
        delay_print("I, the omniscent and omnipotent Mr. Thoe, shall tell you the answer if one were to double that integer. It is... ")
        print(doubleorNothing(n))
        thirdQuestion (suspend)
    elif intCheck(choiceOne) == False:
        print("Please comply and enter a proper input.")
        suspend = suspend - 1
        secondQuestion(suspend)
                    
def thirdQuestion(suspend):
    n = input("Enter YET ANOTHER integer:")
    if suspend < 2:
        print("You are suspended indefinitely for not being able to follow simple instructions.")
        exit()
    if intCheck(n) == True:
        delay_print("I, the omniscent and omnipotent Mr. Thoe, shall tell you the answer if one were to square that integer. It is...")
        print(squareUp(n))
        end(suspend)
    elif intCheck(choiceOne) == False:
        print("Please comply and enter a proper input.")
        suspend = suspend - 1
        thirdQuestion(suspend)

def end(suspend):
    delay_print("Is there anything else you would like to know? \n 1. Why do you say only integers? Why don\'t you say floats if you can perform functions on floats? \n 2. How are you this smart? \n 3. Nah, I'm Fine\n")
    endChoice = input("Input:")
    if suspend < 2:
        print("You are suspended indefinitely for not being able to follow simple instructions.")
        exit()
    if intCheck(endChoice) == True and float(endChoice) == 1:
        delay_print("I saw the movie \'It\' and now floating objects scare me.")
        exit()
    if intCheck(endChoice) == True and float(endChoice) == 2:
        delay_print("You'll never know.")
        exit()
    if intCheck(endChoice) == True and float(endChoice) == 3:
        delay_print("Okay.")
        exit()
    elif intCheck(endChoice) == False or float(endChoice) >= 3 or float(endChoice) <= 0:
        print("Please comply and enter a proper input.")
        suspend = suspend - 1
        end(suspend)


delay_print("Hello! Welcome to Mr. Thoe's Math Class! What's your name? \n")
user = str(input("Name:"))
delay_print("Hello, "+ user + ". Are you ready to learn? \n 1. Yes \n 2. No \n")
choiceOne = input("Input:")
if intCheck(choiceOne) == True and float(choiceOne) == 1:
    firstQuestion(suspend )
if intCheck(choiceOne) == True and float(choiceOne) == 2:
    delay_print("Okay.")
    sleep(3.0)
    choiceOneA (tries, suspend)
if suspend < 1:
    print("You are suspended indefinitely for not being able to follow simple instructions.")
    exit()  
elif intCheck(choiceOne) == False or float(choiceOne) >= 3 or float(choiceOne) <= 0:
    print("Please comply and enter a proper input.")
    suspend = suspend - 1
    choiceOneA(tries, suspend)
