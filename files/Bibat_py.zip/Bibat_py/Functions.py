def addSix(n):
    n = float(n) + 6
    return n
def doubleorNothing(n):
    n = float(n) * 2
    return n
def squareUp(n):
    n = float(n) ** 2
    return n
