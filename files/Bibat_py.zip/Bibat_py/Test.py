from Functions import *
print(addSix(19))
print(doubleorNothing(10))
print(squareUp(32))
