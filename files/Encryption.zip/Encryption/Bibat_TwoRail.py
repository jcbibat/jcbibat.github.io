def encrypt(anyString):
    empty = ''
    empty2 = ''
    count = 0
    for i in (anyString):
        if count%2 == 0:
            empty = empty + i
        else:
            empty2 = empty2 + i
        count = count + 1
    cipher = empty2 + empty

    return cipher


def decrypt(cipher):
    halfLength = len(cipher) // 2
    fir = cipher[:halfLength]
    last = cipher[halfLength:]
    
    decipher = ''
    
    for i in range(halfLength):
        decipher = decipher + last[i]
        decipher = decipher + fir[i]
     
    if len(last) > len(fir):
        decipher = decipher + last[-1]

    return decipher




anyString = input("Type: ")
enc = encrypt(anyString)
print(enc)

decrypt(enc)
dec = decrypt(enc)
print (dec)

