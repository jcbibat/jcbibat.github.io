empty = ''
def encrypt(anyString, empty):
    for i in (anyString):
        x = ord(i)
        if ord(i) != 32:
            x = x + 10
            x = chr(x)
            empty = empty + x
        elif ord(i) == 32:
            empty = empty
    return empty


def decrypt(anyString,empty):
    for i in (anyString):
        x = ord(i) 
        x = x - 10
        x = chr(x)
        empty = empty + x
    return empty

anyString = input("Type: ")
encrypt(anyString, empty)
enc = encrypt(anyString, empty)
print(enc)
decrypt(enc,empty)
dec = decrypt(enc, empty)
print (dec, empty)


