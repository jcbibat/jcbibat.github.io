emptyList = []
def encrypt(anyString, rails):
    for x in range(rails):
        x = ""
        emptyList.append(x)
    count = 0
    posTest = 1
    for i in (anyString):
        if posTest == 1:
            if count%rails == 0:
                emptyList[count] = emptyList[count] + i
            elif count%rails > 0:
                emptyList[count] = emptyList[count] + i
            if count == rails-1:
                posTest = 0
            count = count + 1
        elif posTest == 0:
            if count%rails == 0:
                emptyList[count] = emptyList[count] + i
            elif count%rails > 0:
                emptyList[count] = emptyList[count] + i
            if count == 1:
                posTest = 1
            count = count - 1
    for n in range(rails):
        cipher = cipher + emptyList[n]
    return cipher


def decrypt(cipher):
    halfLength = len(cipher) // 2
    fir = cipher[:halfLength]
    last = cipher[halfLength:]
    
    decipher = ''
    
    for i in range(halfLength):
        decipher = decipher + last[i]
        decipher = decipher + fir[i]
     
    if len(last) > len(fir):
        decipher = decipher + last[-1]

    return decipher



rails = int(input("Number of Rails: "))
anyString = input("Type: ")
encrypt(anyString, rails)

decrypt(enc)
dec = decrypt(enc)
print (dec)

