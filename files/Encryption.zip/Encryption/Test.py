anyString = input("Enter a string: ")
empty = ''
def repVowels(anyString, empty):

    for i in (anyString):
        x = ord(i)
        if x in (65, 69 ,73, 79, 85, 97, 101, 105, 111, 117):
            x = x + 5542
            x = chr(x)
            empty = empty + x
        else:
            x = chr(x)
            empty = empty + x
    return empty

def retVowels(anyString, empty):
    for i in (anyString):
        x = ord(i)
        x = x - 5542
        if x in (65, 69 ,73, 79, 85, 97, 101, 105, 111, 117):
            x = chr(x)
            empty = empty + x
        else:
            x = x + 5542
            x = chr(x)
            empty = empty + x
    return empty

print(repVowels(anyString, empty))
print(retVowels(repVowels(anyString, empty), empty))
