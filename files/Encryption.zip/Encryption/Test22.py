def genRailEncrypt(numRails, plainText):
    cipherText = ""
    railDict = {}
    rail = 0
    for rail in range(numRails):
        railDict["rail"+str(rail)] = ""
        rail += 1
    for i in range(len(plainText)):
        mod = i%numRails
        railDict["rail" + str(mod)] += plainText[i]
    for i in range(numRails):
        cipherText += railDict["rail" + str(i)]
    return cipherText

print(genRailEncrypt(2, "Hello world"))
