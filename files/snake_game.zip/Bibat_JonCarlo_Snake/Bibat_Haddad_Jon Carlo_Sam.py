import pygame
import time
import random

pygame.init()

white = (255,255,255)
black = (0,0,0)
red = (255,0,0)
green = (random.randint(0,255)/2,random.randint(0,255)/2,random.randint(0,255)/2)

display_width = 1200
display_height  = 800
#This is the  section of code where we added our custom apple and snake head.
gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption('Slither')

icon = pygame.image.load('app.png')
pygame.display.set_icon(icon)

img = pygame.image.load('Snek.png')
appleimg = pygame.image.load('app.png')

clock = pygame.time.Clock()

AppleThickness = 30
block_size = 25
FPS = 15


direction = "right"

smallfont = pygame.font.SysFont("raleway",30)
medfont = pygame.font.SysFont("raleway", 50)
largefont = pygame.font.SysFont("raleway", 80)


def pause():

    paused = True
    message_to_screen("Paused",
                      white,
                      -100,
                      size="large")

    message_to_screen("Press C to continue or Q to quit.",
                      white,
                      25)
    pygame.display.update()

    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    paused = False

                elif event.key == pygame.K_q:
                    pygame.quit()
                    quit()

        #gameDisplay.fill(white)
        
        clock.tick(5)
                    

def score(score):
    text = smallfont.render("Score: "+str(score), True, white)
    gameDisplay.blit(text, [0,0])

def randAppleGen(x,y):
    randAppleX = random.randrange(0,x - block_size, 10)
    randAppleY = random.randrange(0,y - block_size, 10)

    return randAppleX,randAppleY



def game_intro():

    intro = True

    while intro:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    intro = False
                if event.key == pygame.K_q:
                    pygame.quit()
                    quit()
   
        gameDisplay.fill(black)
        message_to_screen("Welcome to Slither",
                          green,
                          -100,
                          "large")
        message_to_screen("The objective of the game is to eat red apples",
                          white,
                          -30)

        message_to_screen("The more apples you eat, the longer you get",
                          white,
                          10)

        message_to_screen("If you run into yourself, or the edges, you die!",
                          white,
                          50)

        message_to_screen("Press C to play, P to pause or Q to quit.",
                          white,
                          180)
    
        pygame.display.update()
        clock.tick(15)
        

    


def snake(block_size, snakelist):

    if direction == "right":
        head = pygame.transform.rotate(img, 270)

    if direction == "left":
        head = pygame.transform.rotate(img, 90)

    if direction == "up":
        head = img

    if direction == "down":
        head = pygame.transform.rotate(img, 180)
        
    r = 252
    g = 0
    b = 0
    gameDisplay.blit(head, (snakelist[-1][0], snakelist[-1][1]))
        
#This is where we introduced the color/rainbow modification. We tell the RGB values to change start at red and they end at the other end of the spectrum        
    for XnY in snakelist[:-1]:
        if r == 252 and g < 252 and b == 0:
            g = g + 4
        elif g == 252 and r <= 252 and b == 0:
            if r >= 4:
                r = r - 4
        if g == 252 and r == 0 and b < 252:
                b = b + 4
        elif b == 252 and r == 0 and g <= 252:
            if g >= 4:
                g = g - 4
        if b == 252 and g == 0 and r < 252:
            r = r + 4
        elif r == 252 and g == 0 and b <= 252 :
            if b >= 4:
                b = b -4
        
        pygame.draw.rect(gameDisplay, (r,g,b), [XnY[0],XnY[1],block_size,block_size])

def text_objects(text,color,size):
    if size == "small":
        textSurface = smallfont.render(text, True, color)
    elif size == "medium":
        textSurface = medfont.render(text, True, color)
    elif size == "large":
        textSurface = largefont.render(text, True, color)

    
    return textSurface, textSurface.get_rect()
    
    
def message_to_screen(msg,color, y_displace=0, size = "small"):
    textSurf, textRect = text_objects(msg,color, size)
    textRect.center = (display_width / 2), (display_height / 2)+y_displace
    gameDisplay.blit(textSurf, textRect)


def gameLoop():
    
    global direction

    direction = 'right'
    gameExit = False
    gameOver = False

    lead_x = display_width/2
    lead_y = display_height/2

    lead_x_change = 10
    lead_y_change = 0

    snakeList = []
    snakeLength = 512

    X=random.randint(0, display_width/5)
    Y=random.randint(0, display_height/5)

    x=X*5
    y=Y*5
    

    randAppleX,randAppleY = randAppleGen(x, y)
    
    while not gameExit:

        if gameOver == True:
            message_to_screen("Game over",
                              red,
                              y_displace=-50,
                              size="large")
            
            message_to_screen("Press C to play again or Q to quit",
                              white,
                              50,
                              size="medium")
            
            pygame.display.update()
            

        while gameOver == True:
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    gameOver = False
                    gameExit = True
                    
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        gameExit = True
                        gameOver = False
                    if event.key == pygame.K_c:
                        gameLoop()

        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameExit = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    direction = "left"
                    lead_x_change = -block_size
                    lead_y_change = 0
                elif event.key == pygame.K_RIGHT:
                    direction = "right"
                    lead_x_change = block_size
                    lead_y_change = 0
                elif event.key == pygame.K_UP:
                    direction = "up"
                    lead_y_change = -block_size
                    lead_x_change = 0
                elif event.key == pygame.K_DOWN:
                    direction = "down"
                    lead_y_change = block_size
                    lead_x_change = 0

                elif event.key == pygame.K_p:
                    pause()

        if lead_x >= display_width or lead_x < 0 or lead_y >= display_height or lead_y < 0:
            gameOver = True
      

        lead_x += lead_x_change
        lead_y += lead_y_change
        
        gameDisplay.fill(black)

        
        #pygame.draw.rect(gameDisplay, red, [randAppleX, randAppleY, AppleThickness, AppleThickness])

        gameDisplay.blit(appleimg, (randAppleX, randAppleY))


        snakeHead = []
        snakeHead.append(lead_x)
        snakeHead.append(lead_y)
        snakeList.append(snakeHead)

        if len(snakeList) > snakeLength:
            del snakeList[0]

        for eachSegment in snakeList[:-1]:
            if eachSegment == snakeHead:
                gameOver = True

        
        snake(block_size, snakeList)

        score(snakeLength-1)

        

        
        pygame.display.update()

        if lead_x > randAppleX and lead_x < randAppleX + AppleThickness or lead_x + block_size > randAppleX and lead_x + block_size < randAppleX + AppleThickness:

            if lead_y > randAppleY and lead_y < randAppleY + AppleThickness:

                randAppleX,randAppleY = randAppleGen(x, y)
                snakeLength += 1

            elif lead_y + block_size > randAppleY and lead_y + block_size < randAppleY + AppleThickness:

                randAppleX,randAppleY = randAppleGen(x, y)
                snakeLength += 1
        clock.tick(FPS)
    pygame.quit()  
    quit()
#These are the game difficulties, we assigned a key to each of the frames per second and allowed users to pick what they want.    
def difficulty():
  
    difficulty = True
    global FPS
    while difficulty:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
    
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    FPS = 10
                    difficulty = False
                    
                if event.key == pygame.K_2:
                    FPS = 15
                    difficulty = False
                    
                if event.key == pygame.K_3:
                    FPS = 20
                    difficulty = False
                   
                if event.key == pygame.K_4:
                    FPS = 25
                    difficulty = False
                    
                if event.key == pygame.K_5:
                    FPS = 30
                    difficulty = False
                if event.key == pygame.K_6:
                    FPS = 60
                    difficulty = False
                    
                if event.key == pygame.K_q:
                    pygame.quit()
                    quit()
#We made the background of the screen black
        gameDisplay.fill(black)
        message_to_screen("Choose a difficulty",
                          green,
                          -100,
                          "large")
        message_to_screen("Press 1 for Very Easy",
                          white,
                          -30)

        message_to_screen("Press 2 for Easy",
                          white,
                          10)

        message_to_screen("Press 3 for Normal",
                          white,
                          50)

        message_to_screen("Press 4 for Hard",   
                         white,
                          90)
        message_to_screen("Press 5 for Very Hard",
                          white,
                          130)
    
        pygame.display.update()
        clock.tick(15)
    return FPS
   

        
            
        
        


         

game_intro()
difficulty()
gameLoop()

